﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using Solution_Framework_Kardex.BussinessLogicLayer;
using Solution_Framework_MovimientoPersonal.BussinessLogicLayer;
using Solution_Framework_General.BussinessLogicLayer;

public partial class Precontratacion_CurriculumCandidato : System.Web.UI.Page
{
    private string sc = "";
    private int per_id = 0;
    private string connectionString = ConfigurationManager.ConnectionStrings["CnxSigrh3"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["per_id"] != null && HttpContext.Current.Session["per_id"].ToString() != "")
        {
            if (!Page.IsPostBack)
            {

                if (Request.QueryString["per_id"] != null)
                {
                    per_id = Convert.ToInt32(Request.QueryString["per_id"]);
                }
                else if (Request.QueryString["sol_id"] != null)
                {
                    per_id = ObtenerPerIdPorSolicitud(Convert.ToInt32(Request.QueryString["sol_id"]));
                }
                else
                {
                    per_id = Convert.ToInt32(HttpContext.Current.Session["per_id"]);
                }

                hfPerId.Value = per_id.ToString();

                CargarDatosPersonales(per_id);
                CargarCombos();
                CargarGridViewFormacion(per_id.ToString());
                CargarGridViewCursos(per_id.ToString());
                CargarGridViewTrayectoria(per_id.ToString());
                CargarGridViewIdiomas(per_id.ToString());
                CargarGridViewOtrosConocimientos(per_id.ToString());
            }
        }
        else
        {
            Response.Redirect("../Index");
        }
    }
    private int ObtenerPerIdPorSolicitud(int sol_id)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT per_id FROM SolicitudContratacion WHERE sol_id = @sol_id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@sol_id", sol_id);
                    object result = cmd.ExecuteScalar();
                    conn.Close();

                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                }
            }
            return 0;
        }
        catch
        {
            return 0;
        }
    }
    private void CargarDatosPersonales(int per_id)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string queryPersona = @"
                    SELECT 
                        per_nombres, per_ap_paterno, per_ap_materno,
                        per_fecha_nac, per_num_doc, per_sexo,
                        per_estado_civil, per_procedencia
                    FROM tbl_persona 
                    WHERE per_id = @per_id";

                DataTable dtPersona = new DataTable();
                using (SqlCommand cmd = new SqlCommand(queryPersona, conn))
                {
                    cmd.Parameters.AddWithValue("@per_id", per_id);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dtPersona);
                    }
                }

                if (dtPersona.Rows.Count > 0)
                {
                    DataRow row = dtPersona.Rows[0];

                    ltlNombreCompleto.Text = row["per_nombres"].ToString().Trim() + " " +
                                             row["per_ap_paterno"].ToString().Trim() + " " +
                                             row["per_ap_materno"].ToString().Trim();
                    ltlCarnet.Text = row["per_num_doc"].ToString().Trim();
                    ltlFechaNac.Text = Convert.ToDateTime(row["per_fecha_nac"]).ToString("dd/MM/yyyy");
                    ltlSexo.Text = row["per_sexo"].ToString().Trim() == "M" ? "Masculino" : "Femenino";
                    ltlEstadoCivil.Text = ObtenerDescripcion("estado_civil", row["per_estado_civil"].ToString());
                    ltlNacionalidad.Text = ObtenerDescripcion("pais", row["per_procedencia"].ToString());

                    string queryDomicilio = @"
                        SELECT 
                            perd_email_personal, perd_telefono, perd_celular,
                            perd_ciudad_residencia, perd_descripcion_via, perd_numero
                        FROM tbl_persona_domicilio 
                        WHERE perd_per_id = @per_id";

                    DataTable dtDomicilio = new DataTable();
                    using (SqlCommand cmd = new SqlCommand(queryDomicilio, conn))
                    {
                        cmd.Parameters.AddWithValue("@per_id", per_id);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dtDomicilio);
                        }
                    }

                    if (dtDomicilio.Rows.Count > 0)
                    {
                        DataRow rowD = dtDomicilio.Rows[0];
                        ltlEmail.Text = rowD["perd_email_personal"].ToString().Trim();
                        ltlTelefono.Text = rowD["perd_telefono"].ToString().Trim();
                        ltlCelular.Text = rowD["perd_celular"].ToString().Trim();
                        ltlCiudad.Text = ObtenerDescripcion("ciudad_localidad", rowD["perd_ciudad_residencia"].ToString());
                        ltlDireccion.Text = rowD["perd_descripcion_via"].ToString().Trim() + " N° " + rowD["perd_numero"].ToString().Trim();
                    }
                }
                conn.Close();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al cargar datos personales: " + ex.Message);

        }
    }
    
    private string ObtenerDescripcion(string tabla, string id)
    {
        try
        {
            if (string.IsNullOrEmpty(id) || id == "0")
                return "";

            cls_catalogo catalogo = new cls_catalogo { cat_tabla = tabla };
            DataSet ds = catalogo.ObtenerTablaCombo();

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                DataRow[] rows = ds.Tables[0].Select("cat_id = " + id);
                if (rows.Length > 0)
                {
                    return rows[0]["cat_descripcion"].ToString();
                }
            }
            return id;
        }
        catch
        {
            return id;
        }
    }
    private void CargarCombos()
    {
        try
        {
            cls_grado_academico formacion = new cls_grado_academico();

            ddlFormacion_Institucion.Items.Clear();
            ddlFormacion_Institucion.Items.Add("Seleccione..");
            ddlFormacion_Institucion.DataSource = formacion.ComboFormacion("C2");
            ddlFormacion_Institucion.DataTextField = "it_nombre";
            ddlFormacion_Institucion.DataValueField = "it_id";
            ddlFormacion_Institucion.DataBind();

            ddlCursos_Institucion.Items.Clear();
            ddlCursos_Institucion.Items.Add("Seleccione..");
            ddlCursos_Institucion.DataSource = formacion.ComboFormacion("C7");
            ddlCursos_Institucion.DataTextField = "it_nombre";
            ddlCursos_Institucion.DataValueField = "it_id";
            ddlCursos_Institucion.DataBind();

            ddlTrayectoria_NuevaInstitucion.Items.Clear();
            ddlTrayectoria_NuevaInstitucion.Items.Add("Seleccione..");
            ddlTrayectoria_NuevaInstitucion.DataSource = formacion.ComboFormacion("C7");
            ddlTrayectoria_NuevaInstitucion.DataTextField = "it_nombre";
            ddlTrayectoria_NuevaInstitucion.DataValueField = "it_id";
            ddlTrayectoria_NuevaInstitucion.DataBind();

            ddlFormacionCarrera.Items.Clear();
            ddlFormacionCarrera.Items.Add("Seleccione..");
            ddlFormacionCarrera.DataSource = formacion.ComboFormacionCarreras("C2");
            ddlFormacionCarrera.DataTextField = "carr_nombre";
            ddlFormacionCarrera.DataValueField = "carr_id";
            ddlFormacionCarrera.DataBind();

            cls_cv_formacion cv = new cls_cv_formacion();
            ddlCursos_Curso.Items.Clear();
            ddlCursos_Curso.Items.Add("Seleccione..");
            ddlCursos_Curso.DataSource = cv.ListadoCursos(0, "C2");
            ddlCursos_Curso.DataTextField = "cv_curs_nombre_curso";
            ddlCursos_Curso.DataValueField = "cv_curs_id";
            ddlCursos_Curso.DataBind();

            ddlIdiomas_Idioma.Items.Clear();
            ddlIdiomas_Idioma.Items.Add("Seleccione..");
            ddlIdiomas_Idioma.DataSource = cv.ListadoIdiomas();
            ddlIdiomas_Idioma.DataTextField = "idm_nombre";
            ddlIdiomas_Idioma.DataValueField = "idm_id";
            ddlIdiomas_Idioma.DataBind();

            ddlOtrosC_nombre.Items.Clear();
            ddlOtrosC_nombre.Items.Add("Seleccione..");
            ddlOtrosC_nombre.DataSource = cv.ListadoConocimientos();
            ddlOtrosC_nombre.DataTextField = "cv_oc_conocimiento";
            ddlOtrosC_nombre.DataValueField = "cv_oc_id";
            ddlOtrosC_nombre.DataBind();

            cls_grado_academico grado = new cls_grado_academico();
            ddlFormacionNivel.Items.Clear();
            ddlFormacionNivel.Items.Insert(0, new ListItem("Seleccione...", "0"));
            ddlFormacionNivel.DataSource = grado.ObtenerGradoAcademico();
            ddlFormacionNivel.DataValueField = "ga_id";
            ddlFormacionNivel.DataTextField = "ga_nombre";
            ddlFormacionNivel.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error en CargarCombos: " + ex.Message);
        }
    }
    protected void gvFormacione_PreRender(object sender, EventArgs e)
    {
        if (gvFormacione.Rows.Count > 0)
        {
            gvFormacione.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvFormacione.FooterRow != null)
                gvFormacione.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }

    protected void gvTrayectoria_PreRender(object sender, EventArgs e)
    {
        if (gvTrayectoria.Rows.Count > 0)
        {
            gvTrayectoria.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvTrayectoria.FooterRow != null)
                gvTrayectoria.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }

    protected void gvCursos_PreRender(object sender, EventArgs e)
    {
        if (gvCursos.Rows.Count > 0)
        {
            gvCursos.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvCursos.FooterRow != null)
                gvCursos.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }

    protected void gvIdiomas_PreRender(object sender, EventArgs e)
    {
        if (gvIdiomas.Rows.Count > 0)
        {
            gvIdiomas.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvIdiomas.FooterRow != null)
                gvIdiomas.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }

    protected void gvOtrosConocimientos_PreRender(object sender, EventArgs e)
    {
        if (gvOtrosConocimientos.Rows.Count > 0)
        {
            gvOtrosConocimientos.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvOtrosConocimientos.FooterRow != null)
                gvOtrosConocimientos.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    private void CargarGridViewFormacion(string per_id)
    {
        try
        {
            cls_cv_formacion formacion = new cls_cv_formacion();
            gvFormacione.DataSource = formacion.ObtenerGrilla_Formacion(Convert.ToInt32(per_id));
            gvFormacione.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    private void CargarGridViewCursos(string per_id)
    {
        try
        {
            cls_cv_formacion formacion = new cls_cv_formacion();
            gvCursos.DataSource = formacion.ObtenerGrilla_Cursos(Convert.ToInt32(per_id));
            gvCursos.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    private void CargarGridViewTrayectoria(string per_id)
    {
        try
        {
            cls_cv_formacion formacion = new cls_cv_formacion();
            gvTrayectoria.DataSource = formacion.ObtenerGrilla_Trayectoria(Convert.ToInt32(per_id));
            gvTrayectoria.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    private void CargarGridViewIdiomas(string per_id)
    {
        try
        {
            cls_cv_formacion formacion = new cls_cv_formacion();
            gvIdiomas.DataSource = formacion.ObtenerGrilla_Idiomas(Convert.ToInt32(per_id));
            gvIdiomas.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    private void CargarGridViewOtrosConocimientos(string per_id)
    {
        try
        {
            cls_cv_formacion formacion = new cls_cv_formacion();
            gvOtrosConocimientos.DataSource = formacion.ObtenerGrilla_OtrosC(Convert.ToInt32(per_id));
            gvOtrosConocimientos.DataBind();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }
    protected void btnGuardarCurriculum_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);

            if (perId == 0)
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'No se encontró el ID del funcionario' }, { type: 'danger' });";
                SetScript(sc, "");
                return;
            }

            sc = "$.notify({ icon: 'fas fa-check', message: 'Curriculum guardado correctamente' }, { type: 'success' });";
            SetScript(sc, "");
            Response.Redirect("ListaSolicitudes.aspx");
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al guardar: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }
    protected void btnFormacion_NuevaInst_Click(object sender, EventArgs e)
    {
        txtFormacion_NuevaInstitucion.Text = "";
        sc = "$('#modalFormacion_InstitucionNueva').modal('show');";
        SetScript(sc, "");
    }

    protected void btnFormacion_AdicionarInstitucion_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtFormacion_NuevaInstitucion.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la institución' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("institucion", txtFormacion_NuevaInstitucion.Text.ToUpper().Trim(), "", "0");

            cls_grado_academico formacion = new cls_grado_academico();
            ddlFormacion_Institucion.DataSource = formacion.ComboFormacion("C2");
            ddlFormacion_Institucion.DataTextField = "it_nombre";
            ddlFormacion_Institucion.DataValueField = "it_id";
            ddlFormacion_Institucion.DataBind();
            ddlFormacion_Institucion.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlFormacion_Institucion.SelectedIndex = ddlFormacion_Institucion.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Institución registrada correctamente' }, { type: 'success' }); $('#modalFormacion_InstitucionNueva').modal('hide');";
            SetScript(sc, "");
            txtFormacion_NuevaInstitucion.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnFormacion_NuevaCarrera_Click(object sender, EventArgs e)
    {
        txtFormacion_NuevaCarrera.Text = "";
        sc = "$('#modalFormacion_CarreraNueva').modal('show');";
        SetScript(sc, "");
    }
    protected void btnFormacion_AdicionarCarrera_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtFormacion_NuevaCarrera.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la carrera' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("carrera", txtFormacion_NuevaCarrera.Text.ToUpper().Trim(), "", "0");

            cls_grado_academico formacion = new cls_grado_academico();
            ddlFormacionCarrera.DataSource = formacion.ComboFormacionCarreras("C2");
            ddlFormacionCarrera.DataTextField = "carr_nombre";
            ddlFormacionCarrera.DataValueField = "carr_id";
            ddlFormacionCarrera.DataBind();
            ddlFormacionCarrera.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlFormacionCarrera.SelectedIndex = ddlFormacionCarrera.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Carrera registrada correctamente' }, { type: 'success' }); $('#modalFormacion_CarreraNueva').modal('hide');";
            SetScript(sc, "");
            txtFormacion_NuevaCarrera.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }
    protected void btnAdicionarFormacion_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);
            cls_cv_formacion formacion = new cls_cv_formacion();

            int fechaFin = 0;
            if (!string.IsNullOrEmpty(txtFormacionAñoFin.Text))
            {
                fechaFin = Convert.ToInt32(txtFormacionAñoFin.Text);
            }

            formacion.cv_ga_id = Convert.ToInt32(ddlFormacionNivel.SelectedValue);
            formacion.cv_inst_id = Convert.ToInt32(ddlFormacion_Institucion.SelectedValue);
            formacion.cv_carr_id = Convert.ToInt32(ddlFormacionCarrera.SelectedValue);
            formacion.cv_form_año_inicio = Convert.ToInt32(txtFormacionAñoInicio.Text);
            formacion.cv_form_año_fin = fechaFin;
            formacion.cv_form_prov_nal = rblFormacionProvision.SelectedValue;
            formacion.cv_form_per_id = perId;

            if (formacion.Adicionar())
            {
                sc = "$.notify({ icon: 'fas fa-check', message: 'Formación agregada correctamente' }, { type: 'success' });";
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al agregar formación' }, { type: 'warning' });";
            }

            SetScript(sc, "");
            LimpiarFormacion();
            CargarGridViewFormacion(perId.ToString());
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void gvFormacion_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "GetDelete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string form_id = gvFormacione.DataKeys[index].Values[0].ToString();

                cls_cv_formacion formacion = new cls_cv_formacion();
                formacion.cv_form_id = Convert.ToInt32(form_id);

                if (formacion.Eliminar())
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Eliminado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al eliminar' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                CargarGridViewFormacion(hfPerId.Value);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    private void LimpiarFormacion()
    {
        ddlFormacionNivel.SelectedIndex = 0;
        ddlFormacion_Institucion.SelectedIndex = 0;
        ddlFormacionCarrera.SelectedIndex = 0;
        txtFormacionAñoInicio.Text = "";
        txtFormacionAñoFin.Text = "";
        rblFormacionProvision.ClearSelection();
    }
    protected void btnCursos_NuevaInstitucion_Click(object sender, EventArgs e)
    {
        txtCursos_NuevaInstitucion.Text = "";
        sc = "$('#modalCursos_InstitucionNueva').modal('show');";
        SetScript(sc, "");
    }

    protected void btnCursos_AdicionarInstitucion_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtCursos_NuevaInstitucion.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la institución' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("institucion", txtCursos_NuevaInstitucion.Text.ToUpper().Trim(), "", "0");

            cls_grado_academico formacion = new cls_grado_academico();
            ddlCursos_Institucion.DataSource = formacion.ComboFormacion("C7");
            ddlCursos_Institucion.DataTextField = "it_nombre";
            ddlCursos_Institucion.DataValueField = "it_id";
            ddlCursos_Institucion.DataBind();
            ddlCursos_Institucion.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlCursos_Institucion.SelectedIndex = ddlCursos_Institucion.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Institución registrada correctamente' }, { type: 'success' }); $('#modalCursos_InstitucionNueva').modal('hide');";
            SetScript(sc, "");
            txtCursos_NuevaInstitucion.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnCursos_NuevoCurso_Click(object sender, EventArgs e)
    {
        txtCursos_NuevoCurso.Text = "";
        sc = "$('#modalCursos_CursoNuevo').modal('show');";
        SetScript(sc, "");
    }

    protected void btnCursos_AdicionarCurso_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtCursos_NuevoCurso.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre del curso' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("curso", txtCursos_NuevoCurso.Text.ToUpper().Trim(), "", "0");

            cls_cv_formacion cv = new cls_cv_formacion();
            ddlCursos_Curso.DataSource = cv.ListadoCursos(0, "C2");
            ddlCursos_Curso.DataTextField = "cv_curs_nombre_curso";
            ddlCursos_Curso.DataValueField = "cv_curs_id";
            ddlCursos_Curso.DataBind();
            ddlCursos_Curso.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlCursos_Curso.SelectedIndex = ddlCursos_Curso.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Curso registrado correctamente' }, { type: 'success' }); $('#modalCursos_CursoNuevo').modal('hide');";
            SetScript(sc, "");
            txtCursos_NuevoCurso.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnAdicionarCursos_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);
            cls_cv_formacion formacion = new cls_cv_formacion();

            if (ddlCursos_Institucion.SelectedIndex > 0 && ddlCursos_Curso.SelectedIndex > 0)
            {
                if (formacion.Adicionar_CurriculumCurso(
                    perId,
                    Convert.ToInt32(ddlCursos_Curso.SelectedValue),
                    Convert.ToInt32(ddlCursos_Institucion.SelectedValue),
                    Convert.ToInt32(txtCursosDias.Text),
                    "V"))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Curso agregado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al agregar curso' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                LimpiarCursos();
                CargarGridViewCursos(perId.ToString());
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Complete todos los campos' }, { type: 'warning' });";
                SetScript(sc, "");
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void gvCursos_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "GetDelete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string per_id = gvCursos.DataKeys[index].Values[0].ToString();
                string curs_id = gvCursos.DataKeys[index].Values[1].ToString();

                cls_cv_formacion formacion = new cls_cv_formacion();

                if (formacion.Eliminar_CurriculumCursos(Convert.ToInt32(per_id), Convert.ToInt32(curs_id)))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Eliminado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al eliminar' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                CargarGridViewCursos(hfPerId.Value);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    private void LimpiarCursos()
    {
        ddlCursos_Institucion.SelectedIndex = 0;
        ddlCursos_Curso.SelectedIndex = 0;
        txtCursosDias.Text = "";
    }
    protected void btnTrayectoria_NuevaInstitucion_Click(object sender, EventArgs e)
    {
        txtTrayectoria_NuevaInstitucion.Text = "";
        sc = "$('#modalTrayectoria_NuevaInstitucion').modal('show');";
        SetScript(sc, "");
    }

    protected void btnTrayectoria_AdicionarNuevaInstitucion_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtTrayectoria_NuevaInstitucion.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la institución' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("institucion", txtTrayectoria_NuevaInstitucion.Text.ToUpper().Trim(), "", "0");

            cls_grado_academico formacion = new cls_grado_academico();
            ddlTrayectoria_NuevaInstitucion.DataSource = formacion.ComboFormacion("C7");
            ddlTrayectoria_NuevaInstitucion.DataTextField = "it_nombre";
            ddlTrayectoria_NuevaInstitucion.DataValueField = "it_id";
            ddlTrayectoria_NuevaInstitucion.DataBind();
            ddlTrayectoria_NuevaInstitucion.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlTrayectoria_NuevaInstitucion.SelectedIndex = ddlTrayectoria_NuevaInstitucion.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Institución registrada correctamente' }, { type: 'success' }); $('#modalTrayectoria_NuevaInstitucion').modal('hide');";
            SetScript(sc, "");
            txtTrayectoria_NuevaInstitucion.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnAdicionarTrayectoria_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);
            cls_cv_formacion formacion = new cls_cv_formacion();

            if (ddlTrayectoria_NuevaInstitucion.SelectedIndex > 0)
            {
                if (formacion.Adicionar_CurriculumTrayectoria(
                    Convert.ToInt32(ddlTrayectoria_NuevaInstitucion.SelectedValue),
                    txtTrayectoriaEspecialidad.Text,
                    txtTrayectoriaUltimoCargo.Text,
                    Convert.ToInt32(txtTrayectoriaMesInicio.Text),
                    Convert.ToInt32(txtTrayectoriaAñoInicio.Text),
                    Convert.ToInt32(txtTrayectoriaMesFin.Text),
                    Convert.ToInt32(txtTrayectoriaAñoFin.Text),
                    "V",
                    perId))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Trayectoria agregada correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al agregar trayectoria' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                LimpiarTrayectoria();
                CargarGridViewTrayectoria(perId.ToString());
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Seleccione una institución' }, { type: 'warning' });";
                SetScript(sc, "");
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void gvTrayectoria_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "GetDelete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string form_id = gvTrayectoria.DataKeys[index].Values[0].ToString();

                cls_cv_formacion formacion = new cls_cv_formacion();

                if (formacion.Eliminar_CurriculumTrayectoria(Convert.ToInt32(form_id)))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Eliminado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al eliminar' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                CargarGridViewTrayectoria(hfPerId.Value);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    private void LimpiarTrayectoria()
    {
        ddlTrayectoria_NuevaInstitucion.SelectedIndex = 0;
        txtTrayectoriaEspecialidad.Text = "";
        txtTrayectoriaUltimoCargo.Text = "";
        txtTrayectoriaMesInicio.Text = "";
        txtTrayectoriaAñoInicio.Text = "";
        txtTrayectoriaMesFin.Text = "";
        txtTrayectoriaAñoFin.Text = "";
    }
    protected void btnIdiomas_NuevoIdioma_Click(object sender, EventArgs e)
    {
        txtIdioma_NuevoIdioma.Text = "";
        sc = "$('#modalIdioma_NuevoIdioma').modal('show');";
        SetScript(sc, "");
    }

    protected void btnIdioma_NuevoIdioma_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtIdioma_NuevoIdioma.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre del idioma' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("idioma", txtIdioma_NuevoIdioma.Text.ToUpper().Trim(), "", "0");

            cls_cv_formacion cv = new cls_cv_formacion();
            ddlIdiomas_Idioma.DataSource = cv.ListadoIdiomas();
            ddlIdiomas_Idioma.DataTextField = "idm_nombre";
            ddlIdiomas_Idioma.DataValueField = "idm_id";
            ddlIdiomas_Idioma.DataBind();
            ddlIdiomas_Idioma.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlIdiomas_Idioma.SelectedIndex = ddlIdiomas_Idioma.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Idioma registrado correctamente' }, { type: 'success' }); $('#modalIdioma_NuevoIdioma').modal('hide');";
            SetScript(sc, "");
            txtIdioma_NuevoIdioma.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnAdicionarIdiomas_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);
            cls_cv_formacion formacion = new cls_cv_formacion();

            if (ddlIdiomas_Idioma.SelectedIndex > 0 && ddlIdiomasNivel.SelectedIndex > 0)
            {
                if (formacion.Adicionar_CurriculumIdioma(
                    perId,
                    Convert.ToInt32(ddlIdiomas_Idioma.SelectedValue),
                    "V",
                    ddlIdiomasNivel.SelectedItem.Text))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Idioma agregado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al agregar idioma' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                LimpiarIdiomas();
                CargarGridViewIdiomas(perId.ToString());
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Complete todos los campos' }, { type: 'warning' });";
                SetScript(sc, "");
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void gvIdiomas_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "GetDelete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string per_id = gvIdiomas.DataKeys[index].Values[0].ToString();
                string idio_id = gvIdiomas.DataKeys[index].Values[1].ToString();

                cls_cv_formacion formacion = new cls_cv_formacion();

                if (formacion.Eliminar_CurriculumIdioma(Convert.ToInt32(per_id), Convert.ToInt32(idio_id)))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Eliminado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al eliminar' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                CargarGridViewIdiomas(hfPerId.Value);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    private void LimpiarIdiomas()
    {
        ddlIdiomas_Idioma.SelectedIndex = 0;
        ddlIdiomasNivel.SelectedIndex = 0;
    }
    protected void btnOtrosC_NuevoConocimiento_Click(object sender, EventArgs e)
    {
        txtNuevoC_NuevoC.Text = "";
        sc = "$('#modalOtrosC_NuevoC').modal('show');";
        SetScript(sc, "");
    }

    protected void btnNuevoC_NuevoC_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtNuevoC_NuevoC.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre del conocimiento' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("otro_conocimiento", txtNuevoC_NuevoC.Text.ToUpper().Trim(), "", "0");

            cls_cv_formacion cv = new cls_cv_formacion();
            ddlOtrosC_nombre.DataSource = cv.ListadoConocimientos();
            ddlOtrosC_nombre.DataTextField = "cv_oc_conocimiento";
            ddlOtrosC_nombre.DataValueField = "cv_oc_id";
            ddlOtrosC_nombre.DataBind();
            ddlOtrosC_nombre.Items.Insert(0, new ListItem("Seleccione..", "0"));
            ddlOtrosC_nombre.SelectedIndex = ddlOtrosC_nombre.Items.Count - 1;

            sc = "$.notify({ icon: 'fas fa-check', message: 'Conocimiento registrado correctamente' }, { type: 'success' }); $('#modalOtrosC_NuevoC').modal('hide');";
            SetScript(sc, "");
            txtNuevoC_NuevoC.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void btnAdicionarOtroConocimiento_Click(object sender, EventArgs e)
    {
        try
        {
            int perId = Convert.ToInt32(hfPerId.Value);
            cls_cv_formacion formacion = new cls_cv_formacion();

            if (ddlOtrosC_nombre.SelectedIndex > 0)
            {
                if (formacion.Adicionar_CurriculumOtrosC(
                    perId,
                    Convert.ToInt32(ddlOtrosC_nombre.SelectedValue),
                    "V"))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Conocimiento agregado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al agregar conocimiento' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                LimpiarOtrosConocimientos();
                CargarGridViewOtrosConocimientos(perId.ToString());
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Seleccione un conocimiento' }, { type: 'warning' });";
                SetScript(sc, "");
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    protected void gvOtrosConocimientos_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "GetDelete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string per_id = gvOtrosConocimientos.DataKeys[index].Values[0].ToString();
                string oc_id = gvOtrosConocimientos.DataKeys[index].Values[1].ToString();

                cls_cv_formacion formacion = new cls_cv_formacion();

                if (formacion.Eliminar_CurriculumOtrosC(Convert.ToInt32(per_id), Convert.ToInt32(oc_id)))
                {
                    sc = "$.notify({ icon: 'fas fa-check', message: 'Eliminado correctamente' }, { type: 'success' });";
                }
                else
                {
                    sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al eliminar' }, { type: 'warning' });";
                }

                SetScript(sc, "");
                CargarGridViewOtrosConocimientos(hfPerId.Value);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    private void LimpiarOtrosConocimientos()
    {
        ddlOtrosC_nombre.SelectedIndex = 0;
    }
    private void SetScript(string val, string valS)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append(@"<script type='text/javascript'>");
        sb.Append(val);
        sb.Append("$('.select2').select2({ placeholder: { id: '0', text: 'Seleccione...' }" + valS + " });");
        sb.Append("$('.radios label').addClass('custom-control-label mb-3');");
        sb.Append("$('.radios input[type=\"radio\"]').addClass('custom-control-input mb-3');");
        sb.Append(@"</script>");
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "SIGRHScript", sb.ToString(), false);
    }

    private void SetScript(string val)
    {
        SetScript(val, "");
    }
}

