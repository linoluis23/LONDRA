﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Web;
using Solution_Framework_MovimientoPersonal.BussinessLogicLayer;
using Solution_Framework_General.BussinessLogicLayer;
using Solution_Framework_BienestarSocial.BussinessLogicLayer;
using Solution_Framework_Kardex.BussinessLogicLayer;

public partial class Precontratacion_SolicitudContratacion : System.Web.UI.Page
{
    private cls_persona _persona = null;
    private cls_catalogo _catalogo = null;
    private cls_persona_domicilio _domicilio = null;
    private cls_bs_afp _afp = null;
    private cls_kd_respuesta_combo _grado = null;
    private string sc = "";
    private string connectionString = ConfigurationManager.ConnectionStrings["CnxSigrh3"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["per_id"] != null && HttpContext.Current.Session["per_id"].ToString() != "")
        {
            if (!Page.IsPostBack)
            {
                sc = "CopiarCortarPegar(true);";
                SetScript(sc, "");
                CargarCombos();
                CargarDatosPersonales();
                GenerarCodigoSolicitud();
            }
        }
        else
        {
            Response.Redirect("../Index");
        }
    }

    // ============================================================
    // GENERAR CÓDIGO DE SOLICITUD
    // ============================================================
    private void GenerarCodigoSolicitud()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string checkTable = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SolicitudContratacion'";
                using (SqlCommand cmdCheck = new SqlCommand(checkTable, conn))
                {
                    int tableExists = Convert.ToInt32(cmdCheck.ExecuteScalar());

                    if (tableExists == 0)
                    {
                        lblCodigoSolicitud.Text = "Nuevo";
                        conn.Close();
                        return;
                    }
                }

                string query = "SELECT ISNULL(MAX(sol_id), 0) + 1 FROM SolicitudContratacion";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    int nextId = Convert.ToInt32(cmd.ExecuteScalar());
                    lblCodigoSolicitud.Text = nextId.ToString();
                    ViewState["NextSolId"] = nextId;
                }
                conn.Close();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al generar código: " + ex.Message);
            lblCodigoSolicitud.Text = "Nuevo";
        }
    }

    // ============================================================
    // CARGAR DATOS PERSONALES DESDE EL CI
    // ============================================================
    private void CargarDatosPersonales()
    {
        string ci = Request.QueryString["ci"];

        if (!string.IsNullOrEmpty(ci))
        {
            try
            {
                _persona = new cls_persona();
                DataSet ds = _persona.VerificarNuevoFuncionario(ci, 0);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow row = ds.Tables[0].Rows[0];

                    txtNombres.Text = row["per_nombres"].ToString();
                    txtApPaterno.Text = row["per_ap_paterno"].ToString();
                    txtApMaterno.Text = row["per_ap_materno"].ToString();
                    txtApEsposo.Text = row["per_ap_casada"].ToString();
                    txtNumDoc.Text = row["per_num_doc"].ToString();

                    if (row["per_sexo"].ToString() == "F")
                        ddlSexo.SelectedValue = "F";
                    else
                        ddlSexo.SelectedValue = "M";

                    ddlEstadoCivil.SelectedValue = row["per_estado_civil"].ToString();
                    ddlNacionalidad.SelectedValue = row["per_procedencia"].ToString();
                    ddlLugarNac.SelectedValue = row["per_lugar_nac"].ToString();
                    txtFechaNac.Text = Convert.ToDateTime(row["per_fecha_nac"]).ToString("dd/MM/yyyy");
                    ddlTipoDoc.SelectedValue = row["per_tipo_doc"].ToString();
                    ddlLugarExp.SelectedValue = row["per_lugar_exp"].ToString();

                    if (ddlNacionalidad.SelectedValue == "1")
                    {
                        ddlLugarNac.Enabled = true;
                    }
                    else
                    {
                        ddlLugarNac.SelectedValue = "1822";
                        ddlLugarNac.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar datos: " + ex.Message);
            }
        }
    }

    // ============================================================
    // CARGAR COMBOS 
    // ============================================================
    private void CargarCombos()
    {
        try
        {
            // Tipo de Documento
            _catalogo = new cls_catalogo { cat_tabla = "tipo_documento_personal" };
            ddlTipoDoc.DataSource = _catalogo.ObtenerTablaCombo();
            ddlTipoDoc.DataValueField = "cat_id";
            ddlTipoDoc.DataTextField = "cat_descripcion";
            ddlTipoDoc.DataBind();
            ddlTipoDoc.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Lugar Expedido
            _catalogo = new cls_catalogo { cat_tabla = "departamento" };
            ddlLugarExp.DataSource = _catalogo.ObtenerTablaCombo();
            ddlLugarExp.DataValueField = "cat_id";
            ddlLugarExp.DataTextField = "cat_descripcion";
            ddlLugarExp.DataBind();
            ddlLugarExp.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Estado Civil
            _catalogo = new cls_catalogo { cat_tabla = "estado_civil" };
            ddlEstadoCivil.DataSource = _catalogo.ObtenerTablaCombo();
            ddlEstadoCivil.DataValueField = "cat_id";
            ddlEstadoCivil.DataTextField = "cat_descripcion";
            ddlEstadoCivil.DataBind();
            ddlEstadoCivil.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Nacionalidad
            _catalogo = new cls_catalogo { cat_tabla = "pais" };
            ddlNacionalidad.DataSource = _catalogo.ObtenerTablaCombo();
            ddlNacionalidad.DataValueField = "cat_id";
            ddlNacionalidad.DataTextField = "cat_descripcion";
            ddlNacionalidad.DataBind();
            ddlNacionalidad.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Lugar de Nacimiento
            _catalogo = new cls_catalogo();
            ddlLugarNac.DataSource = _catalogo.ObtenerLugarNacimiento();
            ddlLugarNac.DataValueField = "id_ciudad";
            ddlLugarNac.DataTextField = "lugar_nac";
            ddlLugarNac.DataBind();
            ddlLugarNac.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Departamento
            _catalogo = new cls_catalogo { cat_tabla = "departamento" };
            ddlDepartamento.DataSource = _catalogo.ObtenerTablaCombo();
            ddlDepartamento.DataValueField = "cat_id";
            ddlDepartamento.DataTextField = "cat_descripcion";
            ddlDepartamento.DataBind();
            ddlDepartamento.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // PROVINCIA (inicialmente vacío)
            ddlProvincia.Items.Clear();
            ddlProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // CIUDAD DE RESIDENCIA
            _catalogo = new cls_catalogo { cat_tabla = "ciudad_localidad", cat_id_superior = 0 };
            ddlCiudad.DataSource = _catalogo.ObtenerTablaCombo();
            ddlCiudad.DataValueField = "cat_id";
            ddlCiudad.DataTextField = "cat_descripcion";
            ddlCiudad.DataBind();
            ddlCiudad.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // ZONA
            _catalogo = new cls_catalogo { cat_tabla = "zona", cat_id_superior = 0 };
            ddlZona.DataSource = _catalogo.ObtenerTablaCombo();
            ddlZona.DataValueField = "cat_secuencial";
            ddlZona.DataTextField = "cat_descripcion";
            ddlZona.DataBind();
            ddlZona.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Tipo de Vía
            _catalogo = new cls_catalogo { cat_tabla = "tipo_via" };
            ddlTipoVia.DataSource = _catalogo.ObtenerTablaCombo();
            ddlTipoVia.DataValueField = "cat_id";
            ddlTipoVia.DataTextField = "cat_descripcion";
            ddlTipoVia.DataBind();
            ddlTipoVia.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Combos para el modal de Ciudad
            _catalogo = new cls_catalogo { cat_tabla = "departamento" };
            ddlCiudadDepartamento.DataSource = _catalogo.ObtenerTablaCombo();
            ddlCiudadDepartamento.DataValueField = "cat_id";
            ddlCiudadDepartamento.DataTextField = "cat_descripcion";
            ddlCiudadDepartamento.DataBind();
            ddlCiudadDepartamento.Items.Insert(0, new ListItem("Seleccione...", "0"));

            ddlCiudadProvincia.Items.Clear();
            ddlCiudadProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al cargar combos: " + ex.Message);
        }
    }

    // ============================================================
    // EVENTO: NACIONALIDAD CAMBIA
    // ============================================================
    protected void ddlNacionalidad_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlNacionalidad.SelectedValue == "1")
        {
            ddlLugarNac.SelectedValue = "0";
            ddlLugarNac.Enabled = true;
        }
        else
        {
            ddlLugarNac.SelectedValue = "1822";
            ddlLugarNac.Enabled = false;
        }
    }

    // ============================================================
    // EVENTO: DEPARTAMENTO CAMBIA
    // ============================================================
    protected void ddlDepartamento_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Limpiar provincia y ciudad
        ddlProvincia.Items.Clear();
        ddlProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));
        ddlCiudad.Items.Clear();
        ddlCiudad.Items.Insert(0, new ListItem("Seleccione...", "0"));

        if (ddlDepartamento.SelectedValue != "0")
        {
            int idDepartamento = Convert.ToInt32(ddlDepartamento.SelectedValue);
            CargarProvincias(idDepartamento);
        }

        // Actualizar el UpdatePanel anidado
        UpdatePanelUbicacion.Update();
    }

    // ============================================================
    // EVENTO: PROVINCIA CAMBIA
    // ============================================================
    protected void ddlProvincia_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Limpiar ciudad
        ddlCiudad.Items.Clear();
        ddlCiudad.Items.Insert(0, new ListItem("Seleccione...", "0"));

        if (ddlProvincia.SelectedValue != "0")
        {
            int idProvincia = Convert.ToInt32(ddlProvincia.SelectedValue);
            CargarCiudades(idProvincia);
        }

        // Actualizar el UpdatePanel anidado
        UpdatePanelUbicacion.Update();
    }

    // ============================================================
    // CARGAR PROVINCIAS POR DEPARTAMENTO
    // ============================================================
    private void CargarProvincias(int idDepartamento)
    {
        try
        {
            _catalogo = new cls_catalogo { cat_tabla = "provincia", cat_id_superior = idDepartamento };
            DataSet ds = _catalogo.ObtenerTablaCombo();

            ddlProvincia.DataSource = ds;
            ddlProvincia.DataValueField = "cat_id";
            ddlProvincia.DataTextField = "cat_descripcion";
            ddlProvincia.DataBind();
            ddlProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al cargar provincias: " + ex.Message);
        }
    }

    // ============================================================
    // CARGAR CIUDADES POR PROVINCIA
    // ============================================================
    private void CargarCiudades(int idProvincia)
    {
        try
        {
            _catalogo = new cls_catalogo { cat_tabla = "ciudad_localidad", cat_id_superior = idProvincia };
            DataSet ds = _catalogo.ObtenerTablaCombo();

            ddlCiudad.DataSource = ds;
            ddlCiudad.DataValueField = "cat_id";
            ddlCiudad.DataTextField = "cat_descripcion";
            ddlCiudad.DataBind();
            ddlCiudad.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al cargar ciudades: " + ex.Message);
        }
    }

    // ============================================================
    // EVENTO: NUEVA ZONA - ABRE MODAL
    // ============================================================
    protected void btnNuevaZona_Click(object sender, EventArgs e)
    {
        txtNuevaZona.Text = "";
        sc = "$('#modalNuevaZona').modal('show');";
        SetScript(sc, "");
    }

    // ============================================================
    // EVENTO: REGISTRAR NUEVA ZONA
    // ============================================================
    protected void btnRegistrarZona_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtNuevaZona.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la zona' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            // Registrar la nueva zona
            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("zona", txtNuevaZona.Text.ToUpper().Trim(), "", "0");

            // Recargar combo de zonas
            _catalogo = new cls_catalogo { cat_tabla = "zona", cat_id_superior = 0 };
            ddlZona.DataSource = _catalogo.ObtenerTablaCombo();
            ddlZona.DataValueField = "cat_secuencial";
            ddlZona.DataTextField = "cat_descripcion";
            ddlZona.DataBind();
            ddlZona.Items.Insert(0, new ListItem("Seleccione...", "0"));

            // Seleccionar la nueva zona (último item agregado)
            if (ddlZona.Items.Count > 1)
            {
                ddlZona.SelectedIndex = ddlZona.Items.Count - 1;
            }

            sc = "$.notify({ icon: 'fas fa-check', message: 'Zona registrada correctamente' }, { type: 'success' }); $('#modalNuevaZona').modal('hide'); $('body').removeClass('modal-open'); $('.modal-backdrop').remove();";
            SetScript(sc, "");

            txtNuevaZona.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al registrar zona: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    // ============================================================
    // EVENTO: NUEVA CIUDAD - ABRE MODAL
    // ============================================================
    protected void btnNuevaCiudad_Click(object sender, EventArgs e)
    {
        txtNuevaCiudad.Text = "";
        // Recargar departamentos para el modal
        _catalogo = new cls_catalogo { cat_tabla = "departamento" };
        ddlCiudadDepartamento.DataSource = _catalogo.ObtenerTablaCombo();
        ddlCiudadDepartamento.DataValueField = "cat_id";
        ddlCiudadDepartamento.DataTextField = "cat_descripcion";
        ddlCiudadDepartamento.DataBind();
        ddlCiudadDepartamento.Items.Insert(0, new ListItem("Seleccione...", "0"));

        ddlCiudadProvincia.Items.Clear();
        ddlCiudadProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));

        sc = "$('#modalNuevaCiudad').modal('show');";
        SetScript(sc, "");
    }

    // ============================================================
    // EVENTO: DEPARTAMENTO DEL MODAL CAMBIA
    // ============================================================
    protected void ddlCiudadDepartamento_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCiudadDepartamento.SelectedValue != "0")
        {
            int idDepartamento = Convert.ToInt32(ddlCiudadDepartamento.SelectedValue);
            try
            {
                _catalogo = new cls_catalogo { cat_tabla = "provincia", cat_id_superior = idDepartamento };
                ddlCiudadProvincia.DataSource = _catalogo.ObtenerTablaCombo();
                ddlCiudadProvincia.DataValueField = "cat_id";
                ddlCiudadProvincia.DataTextField = "cat_descripcion";
                ddlCiudadProvincia.DataBind();
                ddlCiudadProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar provincias: " + ex.Message);
            }
        }
        else
        {
            ddlCiudadProvincia.Items.Clear();
            ddlCiudadProvincia.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }
    }

    // ============================================================
    // EVENTO: REGISTRAR NUEVA CIUDAD
    // ============================================================
    protected void btnRegistrarCiudad_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtNuevaCiudad.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el nombre de la ciudad' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlCiudadDepartamento.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar un departamento' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlCiudadProvincia.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar una provincia' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            // Registrar la nueva ciudad
            cls_catalogo catalogo = new cls_catalogo();
            catalogo.Adicionar("ciudad_localidad", txtNuevaCiudad.Text.ToUpper().Trim(), "", Convert.ToInt32(ddlCiudadProvincia.SelectedValue).ToString());

            int idProvincia = Convert.ToInt32(ddlCiudadProvincia.SelectedValue);
            CargarCiudades(idProvincia);

            UpdatePanelUbicacion.Update();

            if (ddlCiudad.Items.Count > 1)
            {
                ddlCiudad.SelectedIndex = ddlCiudad.Items.Count - 1;
            }

            sc = "$.notify({ icon: 'fas fa-check', message: 'Ciudad registrada correctamente' }, { type: 'success' }); $('#modalNuevaCiudad').modal('hide'); $('body').removeClass('modal-open'); $('.modal-backdrop').remove();";
            SetScript(sc, "");

            txtNuevaCiudad.Text = "";
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al registrar ciudad: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    // ============================================================
    // GUARDAR Y REDIRIGIR A CURRICULUM
    // ============================================================
    protected void btnGuardar_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtNombres.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar los Nombres' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtApPaterno.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el Apellido Paterno' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtApMaterno.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el Apellido Materno' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtNumDoc.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el Número de Documento' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtFechaNac.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar la Fecha de Nacimiento' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlDepartamento.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar un Departamento' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlProvincia.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar una Provincia' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlCiudad.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar una Ciudad' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (ddlZona.SelectedValue == "0")
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe seleccionar una Zona' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtDescDomicilio.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar la Descripción del Domicilio' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (string.IsNullOrEmpty(txtNumDomicilio.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar el Número de Domicilio' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            // Verificar que el CI no exista en tbl_persona
            _persona = new cls_persona();
            DataSet dsVerificar = _persona.VerificarNuevoFuncionario(txtNumDoc.Text.Trim(), 0);

            if (dsVerificar.Tables[0].Rows.Count > 0)
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'El CI ya se encuentra registrado en el sistema' }, { type: 'danger' });";
                SetScript(sc, "");
                return;
            }

            // ============================================================
            // 1. GUARDAR PERSONA (tbl_persona)
            // ============================================================
            _persona = new cls_persona();
            _persona.ObtenerId();

            _persona.per_id = Convert.ToInt32(_persona.per_id);
            _persona.per_tipo_doc = Convert.ToInt32(ddlTipoDoc.SelectedValue);
            _persona.per_num_doc = txtNumDoc.Text.ToUpper().Trim();
            _persona.per_lugar_exp = Convert.ToInt32(ddlLugarExp.SelectedValue);
            _persona.per_ap_paterno = txtApPaterno.Text.ToUpper().Trim();
            _persona.per_ap_materno = txtApMaterno.Text.ToUpper().Trim();
            _persona.per_nombres = txtNombres.Text.ToUpper().Trim();
            _persona.per_ap_casada = txtApEsposo.Text.ToUpper().Trim();
            _persona.per_sexo = ddlSexo.SelectedValue;
            _persona.per_fecha_nac = Convert.ToDateTime(txtFechaNac.Text.Trim());
            _persona.per_procedencia = Convert.ToInt32(ddlNacionalidad.SelectedValue);
            _persona.per_lugar_nac = Convert.ToInt32(ddlLugarNac.SelectedValue);
            _persona.per_estado_civil = Convert.ToInt32(ddlEstadoCivil.SelectedValue);
            _persona.per_serie_libreta_militar = txtLibretaMilitar.Text.ToUpper().Trim();

            _persona.Adicionar();

            // ============================================================
            // 2. GUARDAR DOMICILIO (tbl_persona_domicilio)
            // ============================================================
            _domicilio = new cls_persona_domicilio
            {
                perd_per_id = _persona.per_id,
                perd_ciudad_residencia = Convert.ToInt32(ddlCiudad.SelectedValue),
                perd_zona = Convert.ToInt32(ddlZona.SelectedValue),
                perd_tipo_via = Convert.ToInt32(ddlTipoVia.SelectedValue),
                perd_descripcion_via = txtDescDomicilio.Text.ToUpper().Trim(),
                perd_numero = txtNumDomicilio.Text.ToUpper().Trim(),
                perd_telefono = txtTelefono.Text.Trim(),
                perd_celular = txtCelular.Text.Trim(),
                perd_email = txtEmail.Text.Trim()
            };
            _domicilio.Adicionar();

            // ============================================================
            // 3. GUARDAR AFP (tbl_bs_afp)
            // ============================================================
            _afp = new cls_bs_afp();
            _afp.afp_per_id = _persona.per_id;
            _afp.afp_previsora = "GP";
            _afp.afp_fecha_filiacion = DateTime.Now;
            _afp.afp_estado_carnet = "V";
            _afp.afp_usuario = Convert.ToInt32(Session["per_id"].ToString());
            _afp.afp_nua = "0";
            _afp.Adicionar();

            // ============================================================
            // 4. GUARDAR FORMACIÓN ACADÉMICA (tbl_kd_respuesta_combo)
            // ============================================================
            _grado = new cls_kd_respuesta_combo();
            _grado.ef_nivel_instruccion = 0;
            _grado.ef_per_id = _persona.per_id;
            _grado.RegistrarFormacion();

            // ============================================================
            // 5. GUARDAR SOLICITUD (tbl_SolicitudContratacion)
            // ============================================================
            int solId = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string checkTable = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SolicitudContratacion'";
                using (SqlCommand cmdCheck = new SqlCommand(checkTable, conn))
                {
                    int tableExists = Convert.ToInt32(cmdCheck.ExecuteScalar());

                    if (tableExists > 0)
                    {
                        string query = @"
                            INSERT INTO SolicitudContratacion (
                                per_id, sol_nombres, sol_ap_paterno, sol_ap_materno, sol_ap_esposo,
                                sol_sexo, sol_tipo_doc, sol_num_doc, sol_lugar_exp,
                                sol_estado_civil, sol_fecha_nac, sol_nacionalidad, sol_lugar_nac,
                                sol_ciudad_residencia, sol_zona, sol_desc_domicilio, sol_num_domicilio,
                                sol_telefono, sol_celular, sol_email, sol_libreta_militar,
                                sol_estado, sol_usuario_registro, sol_fecha_registro
                            ) VALUES (
                                @per_id, @nombres, @ap_paterno, @ap_materno, @ap_esposo,
                                @sexo, @tipo_doc, @num_doc, @lugar_exp,
                                @estado_civil, @fecha_nac, @nacionalidad, @lugar_nac,
                                @ciudad_residencia, @zona, @desc_domicilio, @num_domicilio,
                                @telefono, @celular, @email, @libreta_militar,
                                'PENDIENTE', @usuario, GETDATE()
                            );
                            SELECT SCOPE_IDENTITY();";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@per_id", _persona.per_id);
                            cmd.Parameters.AddWithValue("@nombres", txtNombres.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@ap_paterno", txtApPaterno.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@ap_materno", txtApMaterno.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@ap_esposo", txtApEsposo.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@sexo", ddlSexo.SelectedValue);
                            cmd.Parameters.AddWithValue("@tipo_doc", Convert.ToInt32(ddlTipoDoc.SelectedValue));
                            cmd.Parameters.AddWithValue("@num_doc", txtNumDoc.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@lugar_exp", Convert.ToInt32(ddlLugarExp.SelectedValue));
                            cmd.Parameters.AddWithValue("@estado_civil", Convert.ToInt32(ddlEstadoCivil.SelectedValue));
                            cmd.Parameters.AddWithValue("@fecha_nac", Convert.ToDateTime(txtFechaNac.Text.Trim()));
                            cmd.Parameters.AddWithValue("@nacionalidad", Convert.ToInt32(ddlNacionalidad.SelectedValue));
                            cmd.Parameters.AddWithValue("@lugar_nac", Convert.ToInt32(ddlLugarNac.SelectedValue));
                            cmd.Parameters.AddWithValue("@ciudad_residencia", Convert.ToInt32(ddlCiudad.SelectedValue));
                            cmd.Parameters.AddWithValue("@zona", Convert.ToInt32(ddlZona.SelectedValue));
                            cmd.Parameters.AddWithValue("@desc_domicilio", txtDescDomicilio.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@num_domicilio", txtNumDomicilio.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@telefono", txtTelefono.Text.Trim());
                            cmd.Parameters.AddWithValue("@celular", txtCelular.Text.Trim());
                            cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                            cmd.Parameters.AddWithValue("@libreta_militar", txtLibretaMilitar.Text.ToUpper().Trim());
                            cmd.Parameters.AddWithValue("@usuario", Convert.ToInt32(Session["per_id"].ToString()));

                            solId = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                    }
                    else
                    {
                        sc = "$.notify({ icon: 'fas fa-warning', message: 'La tabla SolicitudContratacion no existe. Solo se guardó la persona.' }, { type: 'warning' });";
                        SetScript(sc, "");
                    }
                }
                conn.Close();
            }

            // ============================================================
            // 6. REDIRIGIR AL CURRICULUM
            // ============================================================
            sc = "$.notify({ icon: 'fas fa-check', message: 'Solicitud registrada correctamente' }, { type: 'success' });";
            SetScript(sc, "");

            if (solId > 0)
            {
                Response.Redirect("CurriculumCandidato.aspx?sol_id=" + solId);
            }
            else
            {
                Response.Redirect("CurriculumCandidato.aspx?per_id=" + _persona.per_id);
            }
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al guardar: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    // ============================================================
    // CANCELAR
    // ============================================================
    protected void btnCancelar_Click(object sender, EventArgs e)
    {
        Response.Redirect("ListaSolicitudes.aspx");
    }

    // ============================================================
    // SET SCRIPT
    // ============================================================
    private void SetScript(string val, string valS)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append(@"<script type='text/javascript'>");
        sb.Append(val);
        sb.Append("$('.table').DataTable({" +
                "'language': {" +
                    "'sProcessing': 'Procesando...'," +
                    "'sLengthMenu': 'Mostrar _MENU_ registros'," +
                    "'sZeroRecords': 'No se encontraron resultados'," +
                    "'sEmptyTable': 'Ningún dato disponible en esta tabla'," +
                    "'sInfo': 'Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros'," +
                    "'sInfoEmpty': 'Mostrando registros del 0 al 0 de un total de 0 registros'," +
                    "'sInfoFiltered': '(filtrado de un total de _MAX_ registros)'," +
                    "'sInfoPostFix': ''," +
                    "'sSearch': 'Buscar:'," +
                    "'sUrl': ''," +
                    "'sInfoThousands': ','," +
                    "'sLoadingRecords': 'Cargando...'," +
                    "'oPaginate': {" +
                        "'sFirst': '«'," +
                        "'sLast': '»'," +
                        "'sNext': '<i class=\"fas fa-angle-right\"></i>'," +
                        "'sPrevious': '<i class=\"fas fa-angle-left\"></i>'" +
                    "}," +
                    "'oAria': {" +
                        "'sSortAscending': ': Activar para ordenar la columna de manera ascendente'," +
                        "'sSortDescending': ': Activar para ordenar la columna de manera descendente'" +
                    "}" +
                "}," +
                "'ordering': false," +
                "'searching': true," +
                "'autoWidth': false," +
                "'orderCellsTop': true," +
                "'fixedHeader': true" +
            "});");
        sb.Append("$('.numero').on('input', function (event) {" +
                "this.value = this.value.replace(/[^0-9]/g, '');" +
            "});");
        sb.Append("$('.letras').on('input', function () {" +
                "this.value = this.value.replace(/[^A-Z\u00F1\u00D1 ]+$/i, '');" +
            "});");
        sb.Append("$('.select2').select2({ placeholder: { id: '0', text: 'Seleccione...' }" + valS + " });");
        sb.Append("$(\".radios label\").addClass(\"custom-control-label mb-3\");" +
            "$(\".radios input[type='radio']\").addClass(\"custom-control-input mb-3\");");
        sb.Append("$(function () {" +
                "$(\"body\").delegate(\".datepickerD\", \"focusin\", function () {" +
                    "$(this).datepicker({" +
                        "format: \"dd/mm/yyyy\"," +
                        "autoclose: true," +
                        "language: 'es'" +
                    "});" +
                "});" +
                "var me = $(\".datepickerD\");" +
                "me.mask('99/99/9999');" +
            "});");
        sb.Append(@"</script>");
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "SIGRHScript", sb.ToString(), false);
    }

    private void SetScript(string val)
    {
        SetScript(val, "");
    }
}