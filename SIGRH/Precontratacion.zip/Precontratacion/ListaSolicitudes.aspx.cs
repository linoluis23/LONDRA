﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web;
using Solution_Framework_MovimientoPersonal.BussinessLogicLayer;

public partial class Precontratacion_ListaSolicitudes : System.Web.UI.Page
{
    private cls_persona _persona = null;
    private string sc = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        // Verificar sesión
        if (HttpContext.Current.Session["per_id"] != null && HttpContext.Current.Session["per_id"].ToString() != "")
        {
            if (!Page.IsPostBack)
            {
                sc = "CopiarCortarPegar(true);";
                SetScript(sc, "");
            }
        }
        else
        {
            Response.Redirect("../Index");
        }
    }

    protected void btnBuscar_Click(object sender, EventArgs e)
    {
        try
        {
            // 1. Validación de campos vacíos
            if (string.IsNullOrEmpty(txtApPaterno_b.Text) &&
                string.IsNullOrEmpty(txtApMaterno_b.Text) &&
                string.IsNullOrEmpty(txtNombres_b.Text) &&
                string.IsNullOrEmpty(txtCI_b.Text) &&
                string.IsNullOrEmpty(txtCodigo_b.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar algún parámetro de búsqueda' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            // 2. Instanciamos la clase persona (Ahora usa el SP con C7A)
            _persona = new cls_persona();

            // 3. LLAMAMOS AL MÉTODO (El método ObtenerTablaGrilla__persona_gamlp ya fue modificado en la capa de datos para usar C7A)
            DataSet ds = _persona.ObtenerTablaGrilla__persona_gamlp(
                txtCodigo_b.Text.Trim(),      // per_id (Código)
                "",                           // per_tipo_doc
                txtCI_b.Text.Trim(),          // per_num_doc (Carnet)
                "",                           // per_lugar_exp
                txtApPaterno_b.Text.Trim(),   // per_ap_paterno
                txtApMaterno_b.Text.Trim(),   // per_ap_materno
                txtNombres_b.Text.Trim(),     // per_nombres
                "", "", "", "", "", "", ""    // Parámetros opcionales vacíos
            );

            // 4. Asignamos al GridView
            gvResultados.DataSource = ds;
            gvResultados.DataBind();

            if (ds.Tables[0].Rows.Count > 0)
            {
                sc = "$('#dResult').css('display', 'block');";
                sc += "$.notify({ icon: 'fas fa-check', message: 'Funcionarios encontrados.' }, { type: 'success' });";
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'No se han encontrado funcionarios con esos datos' }, { type: 'warning' }); $('#dResult').css('display', 'none');";
            }
            SetScript(sc, "");
        }
        catch (Exception ex)
        {
            sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al buscar: " + ex.Message.Replace("'", "\\'") + "' }, { type: 'danger' });";
            SetScript(sc, "");
        }
    }

    // VERIFICA SI EL FUNCIONARIO EXISTE O NO 
    protected void btnVerificarCI_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtCIVerificacion.Text))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Debe ingresar un número de Carnet de Identidad' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtCIVerificacion.Text, @"^\d+$"))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'El Carnet de Identidad solo debe contener números' }, { type: 'warning' });";
                SetScript(sc, "");
                return;
            }

            string ci = txtCIVerificacion.Text.Trim();

            _persona = new cls_persona();
            DataSet ds = _persona.VerificarNuevoFuncionario(ci, 0);

            if (ds.Tables[0].Rows.Count == 0)
            {
                sc = "$.notify({ icon: 'fas fa-check', message: 'CI verificado correctamente. Redirigiendo...' }, { type: 'success' });";
                SetScript(sc, "");

                string script = "setTimeout(function(){ window.location='SolicitudContratacion.aspx?ci=" + ci + "'; }, 1500);";
                ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", script, true);
            }
            else
            {
                // CI EXISTE
                string mensaje = "";
                try
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    string nombre = row["per_nombres"].ToString();
                    string apPaterno = row["per_ap_paterno"].ToString();
                    string apMaterno = row["per_ap_materno"].ToString();
                    mensaje = $"El funcionario {nombre} {apPaterno} {apMaterno} con Carnet {ci} ya se encuentra registrado.";
                }
                catch
                {
                    mensaje = $"Ya existe un funcionario con el Carnet de Identidad {ci}.";
                }

                sc = "$.notify({ icon: 'fas fa-exclamation', message: '" + mensaje.Replace("'", "\\'") + "' }, { type: 'danger' });";
                SetScript(sc, "");
                txtCIVerificacion.Text = "";
            }
        }
        catch (Exception ex)
        {
            string ci = txtCIVerificacion.Text.Trim();
            if (!string.IsNullOrEmpty(ci))
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Ya existe un funcionario con el Carnet de Identidad " + ci + ".' }, { type: 'danger' });";
            }
            else
            {
                sc = "$.notify({ icon: 'fas fa-exclamation', message: 'Error al verificar el Carnet de Identidad' }, { type: 'danger' });";
            }
            SetScript(sc, "");
            txtCIVerificacion.Text = "";
        }
    }

    protected void btnCancelarVerificacionCI_Click(object sender, EventArgs e)
    {
        txtCIVerificacion.Text = "";
        sc = "$('#modalVerificarCI').modal('hide');";
        SetScript(sc, "");
    }

    protected void gvResultados_PreRender(object sender, EventArgs e)
    {
        if (gvResultados.Rows.Count > 0)
        {
            if (gvResultados.HeaderRow != null)
                gvResultados.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gvResultados.FooterRow != null)
                gvResultados.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }

    private void SetScript(string val, string valS = "")
    {
        StringBuilder sb = new StringBuilder();
        sb.Append(@"<script type='text/javascript'>");
        sb.Append(val);
        sb.Append("$('.table').DataTable({" +
                "'language': {" +
                    "'sProcessing': 'Procesando...'," +
                    "'sLengthMenu': 'Mostrar _MENU_ registros'," +
                    "'sZeroRecords': 'No se encontraron resultados'," +
                    "'sEmptyTable': 'Ningún dato disponible en esta tabla'," +
                    "'sInfo': 'Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros'," +
                    "'sInfoEmpty': 'Mostrando registros del 0 al 0 de un total de 0 registros'," +
                    "'sInfoFiltered': '(filtrado de un total de _MAX_ registros)'," +
                    "'sInfoPostFix': ''," +
                    "'sSearch': 'Buscar:'," +
                    "'sUrl': ''," +
                    "'sInfoThousands': ','," +
                    "'sLoadingRecords': 'Cargando...'," +
                    "'oPaginate': {" +
                        "'sFirst': '«'," +
                        "'sLast': '»'," +
                        "'sNext': '<i class=\"fas fa-angle-right\"></i>'," +
                        "'sPrevious': '<i class=\"fas fa-angle-left\"></i>'" +
                    "}," +
                    "'oAria': {" +
                        "'sSortAscending': ': Activar para ordenar la columna de manera ascendente'," +
                        "'sSortDescending': ': Activar para ordenar la columna de manera descendente'" +
                    "}" +
                "}," +
                "'ordering': false," +
                "'searching': true," +
                "'autoWidth': false," +
                "'orderCellsTop': true," +
                "'fixedHeader': true" +
            "});");
        sb.Append("$('.numero').on('input', function (event) {" +
                "this.value = this.value.replace(/[^0-9]/g, '');" +
            "});");
        sb.Append("$('.letras').on('input', function () {" +
                "this.value = this.value.replace(/[^A-Z\u00F1\u00D1 ]+$/i, '');" +
            "});");
        sb.Append("$('.tooltip').css('display', 'none');" +
            "$('[data-toggle=\"tooltip\"]').tooltip({ trigger: 'hover' });");
        sb.Append("$('.select2').select2({ placeholder: { id: '0', text: 'Seleccione...' }" + valS + " });");
        sb.Append("$('.radios label').addClass('custom-control-label mb-3');" +
            "$('.radios input[type=\"radio\"]').addClass('custom-control-input mb-3');");
        sb.Append(@"</script>");
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "SIGRHScript", sb.ToString(), false);
    }
}